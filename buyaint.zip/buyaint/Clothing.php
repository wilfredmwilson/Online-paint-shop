<?php
 include'header.php';
?>

<div class="container">
    <h5>CLOTHING</h5>
<div class="row">
            <div class="col-md-3 col-sm-6 col-6">
              <div class="product-img">
                <img src="img/g3.png" width="100%" class="img-fluid">
              </div>
              <div class="product-button">
                <button>Add to cart</button>
              </div>
              <div class="details text-center">
                <h6>Arcu vitae imperdiet simply</h6> 
                <span>$235.00</span>               
              </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
              <div class="product-img">
                <img src="img/g1.png" width="100%" class="img-fluid">
              </div>
              <div class="product-button">
                <button>Add to cart</button>
              </div>
              <div class="details text-center">
                <h6>Arcu vitae imperdiet simply</h6> 
                <span>$235.00</span>               
              </div>
            </div>
            <div class="col-md-3 col-sm-6  col-6">
              <div class="product-img">
                <img src="img/g2.png" width="100%" class="img-fluid">
              </div>
              <div class="product-button">
                <button>Add to cart</button>
              </div>
              <div class="details text-center">
                <h6>Arcu vitae imperdiet simply</h6> 
                <span>$235.00</span>               
              </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
              <div class="product-img">
                <img src="img/g3.png" width="100%" class="img-fluid">
              </div>
              <div class="product-button">
                <button>Add to cart</button>
              </div>
              <div class="details text-center">
                <h6>Arcu vitae imperdiet simply</h6> 
                <span>$235.00</span>               
              </div>
            </div>
            
          </div>
</div>


<?php
 include'footer.php';
?>